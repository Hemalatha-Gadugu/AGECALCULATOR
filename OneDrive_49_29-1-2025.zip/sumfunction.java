
public class sumfunction {
    public static void main(String[] args) {
        int num1 = 5;
        int num2 = 10;
        int result = sum(num1, num2);
        System.out.println("The sum is: " + result);
    }

    public static int sum(int a, int b) {
        return a + b;
    }
}

