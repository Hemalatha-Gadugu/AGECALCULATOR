public class asciivalues{
    public static void main(String[] args) {
        char ch='A';
        System.out.println("Ascci value is "+(int)ch);
    }
}