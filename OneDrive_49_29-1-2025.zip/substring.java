
public class substring {
    public static void main(String[] args) {
        String inputString = "Hello, World!";
        int startIndex = 7;
        int endIndex = 12;
        String substring = inputString.substring(startIndex, endIndex);
        System.out.println("Extracted substring: " + substring);
    }
}

    

