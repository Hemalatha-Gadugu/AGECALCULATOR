public class mathpow {
    public static void main(String[] args) {
        // Example base and exponent
        double base = 2;
        double exponent = 3;

        // Calculate the power using Math.pow()
        double result = Math.pow(base, exponent);

        // Display the result
        System.out.println(base + " raised to the power of " + exponent + " is: " + result);
    }
}

